-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 17, 2024 at 08:20 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sgn`
--

-- --------------------------------------------------------

--
-- Table structure for table `categorias`
--

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categorias`
--

INSERT INTO `categorias` (`id`, `nome`) VALUES
(1, 'Desporto'),
(2, 'Negócios'),
(3, 'Política'),
(4, 'Actualidade'),
(5, 'Moda'),
(6, 'Tecnolgia'),
(7, 'Cultura'),
(8, 'Gastronomia'),
(9, 'Música'),
(10, 'Cinema'),
(11, 'Religião');

-- --------------------------------------------------------

--
-- Table structure for table `empresa`
--

CREATE TABLE `empresa` (
  `id` int(11) NOT NULL,
  `nif` varchar(50) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `razao_social` varchar(255) NOT NULL,
  `endereco` varchar(255) NOT NULL,
  `telefone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `site` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `empresa`
--

INSERT INTO `empresa` (`id`, `nif`, `nome`, `razao_social`, `endereco`, `telefone`, `email`, `site`) VALUES
(1, '005076743LA046', 'G4News', 'Portal de Notícias', 'Av 21 de Janeiro, Morro Bento', '(21) 2548 7070', 'gruponews@empresa.com', 'https://www.g4news.ao/');

-- --------------------------------------------------------

--
-- Table structure for table `noticias`
--

CREATE TABLE `noticias` (
  `id` int(11) NOT NULL,
  `titulo` varchar(10) NOT NULL,
  `texto` text NOT NULL,
  `categoria` varchar(50) NOT NULL,
  `imagem` varchar(100) NOT NULL,
  `publicado_por` varchar(100) NOT NULL,
  `data_pub` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `noticias`
--

INSERT INTO `noticias` (`id`, `titulo`, `texto`, `categoria`, `imagem`, `publicado_por`, `data_pub`) VALUES
(9, 'A beleza', '<p>A belaza do M&aacute;rcio Wagner.</p>\r\n<p>Ele &eacute;:</p>\r\n<ul style=\"list-style-type: disc;\">\r\n<li><span style=\"background-color: #ff6600;\">Bonito</span></li>\r\n<li><span style=\"background-color: #ff6600;\">Alto</span></li>\r\n<li><span style=\"background-color: #ff6600;\">Fofo</span></li>\r\n</ul>', 'Moda', '../imagens/imagens_noticias/659ecfe535189.jpg', 'Márcio da Costa', '2024-01-10 17:12:05'),
(10, 'hoje', '<p>Espumou</p>', 'Actualidade', '../imagens/imagens_noticias/65a05a5a4aa8d.jpg', 'Márcio da Costa', '2024-01-11 21:15:06'),
(11, 'O boda do ', '<p>O boda do Rapper angolano&nbsp; <strong>Klienton Ventura</strong> &eacute; consideradod por muitos \"O melhor de todos os tempos!\"</p>\r\n<p>Na passada quarta-feira .</p>', 'Actualidade', '../imagens/imagens_noticias/65a4d0e3a9666.jpg', 'aa', '2024-01-15 06:29:55'),
(13, 'Relogios c', '<p>Os Rel&oacute;gios podem ser encontrados v&aacute;rias lojas da cidade capital comercializados na faixa dos 450 aos 750 mil kwanzas&nbsp;</p>\r\n<p>H&aacute; quem ache os pre&ccedil;os sup&eacute;rfulos e outros at&eacute; barato \"kkk\" ,</p>\r\n<p>gsadrbct4qw68r46ctbvtb78vbt6743rtvb643vbtr346tvrbb5vb52yc5nbyr349q28cyrf43c6t43rt6c9b6v346rt973v6g3&nbsp;</p>\r\n<p>gsadrbct4qw68r46ctbvtb78vbt6743rtvb643vbtr346tvrbb5vb52yc5nbyr349q28cyrf43c6t43rt6c9b6v346rt973v6g3&nbsp;</p>\r\n<p>gsadrbct4qw68r46ctbvtb78vbt6743rtvb643vbtr346tvrbb5vb52yc5nbyr349q28cyrf43c6t43rt6c9b6v346rt973v6g3&nbsp;</p>\r\n<p>gsadrbct4qw68r46ctbvtb78vbt6743rtvb643vbtr346tvrbb5vb52yc5nbyr349q28cyrf43c6t43rt6c9b6v346rt973v6g3&nbsp;</p>\r\n<p>gsadrbct4qw68r46ctbvtb78vbt6743rtvb643vbtr346tvrbb5vb52yc5nbyr349q28cyrf43c6t43rt6c9b6v346rt973v6g3</p>\r\n<p>&nbsp;</p>\r\n<p>gsadrbct4qw68r46ctbvtb78vbt6743rtvb643vbtr346tvrbb5vb52yc5nbyr349q28cyrf43c6t43rt6c9b6v346rt973v6g3&nbsp;</p>\r\n<p>gsadrbct4qw68r46ctbvtb78vbt6743rtvb643vbtr346tvrbb5vb52yc5nbyr349q28cyrf43c6t43rt6c9b6v346rt973v6g3&nbsp;</p>\r\n<p>gsadrbct4qw68r46ctbvtb78vbt6743rtvb643vbtr346tvrbb5vb52yc5nbyr349q28cyrf43c6t43rt6c9b6v346rt973v6g3&nbsp;</p>\r\n<p>gsadrbct4qw68r46ctbvtb78vbt6743rtvb643vbtr346tvrbb5vb52yc5nbyr349q28cyrf43c6t43rt6c9b6v346rt973v6g3&nbsp;</p>\r\n<p>gsadrbct4qw68r46ctbvtb78vbt6743rtvb643vbtr346tvrbb5vb52yc5nbyr349q28cyrf43c6t43rt6c9b6v346rt973v6g3</p>\r\n<p>&nbsp;</p>\r\n<p>gsadrbct4qw68r46ctbvtb78vbt6743rtvb643vbtr346tvrbb5vb52yc5nbyr349q28cyrf43c6t43rt6c9b6v346rt973v6g3&nbsp;</p>\r\n<p>gsadrbct4qw68r46ctbvtb78vbt6743rtvb643vbtr346tvrbb5vb52yc5nbyr349q28cyrf43c6t43rt6c9b6v346rt973v6g3&nbsp;</p>\r\n<p>gsadrbct4qw68r46ctbvtb78vbt6743rtvb643vbtr346tvrbb5vb52yc5nbyr349q28cyrf43c6t43rt6c9b6v346rt973v6g3&nbsp;</p>\r\n<p>gsadrbct4qw68r46ctbvtb78vbt6743rtvb643vbtr346tvrbb5vb52yc5nbyr349q28cyrf43c6t43rt6c9b6v346rt973v6g3&nbsp;</p>\r\n<p>gsadrbct4qw68r46ctbvtb78vbt6743rtvb643vbtr346tvrbb5vb52yc5nbyr349q28cyrf43c6t43rt6c9b6v346rt973v6g3</p>\r\n<p>gsadrbct4qw68r46ctbvtb78vbt6743rtvb643vbtr346tvrbb5vb52yc5nbyr349q28cyrf43c6t43rt6c9b6v346rt973v6g3&nbsp;</p>\r\n<p>gsadrbct4qw68r46ctbvtb78vbt6743rtvb643vbtr346tvrbb5vb52yc5nbyr349q28cyrf43c6t43rt6c9b6v346rt973v6g3&nbsp;</p>\r\n<p>gsadrbct4qw68r46ctbvtb78vbt6743rtvb643vbtr346tvrbb5vb52yc5nbyr349q28cyrf43c6t43rt6c9b6v346rt973v6g3&nbsp;</p>\r\n<p>gsadrbct4qw68r46ctbvtb78vbt6743rtvb643vbtr346tvrbb5vb52yc5nbyr349q28cyrf43c6t43rt6c9b6v346rt973v6g3&nbsp;</p>\r\n<p>gsadrbct4qw68r46ctbvtb78vbt6743rtvb643vbtr346tvrbb5vb52yc5nbyr349q28cyrf43c6t43rt6c9b6v346rt973v6g3</p>\r\n<p>&nbsp;</p>', 'Negócios', '', 'Marcio', '2024-01-16 23:20:13'),
(14, 'Camisas a ', '<p>As camisas s&atilde;o vendidas no valor de 1 milh&atilde;o de kwanzas&nbsp;</p>', 'Negócios', '', 'Márcio Wagner', '2024-01-17 00:05:00'),
(15, 'A', '<p>aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa</p>', 'Actualidade', '', 'Márcio Wagner', '2024-01-17 01:51:52');

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `permissao` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `email`, `telefone`, `foto`, `senha`, `permissao`) VALUES
(14, 'Márcio Wagner', 'marcio@gmail.com', 'marcio@gmail.com', '', '202cb962ac59075b964b07152d234b70', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `noticias`
--
ALTER TABLE `noticias`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `noticias`
--
ALTER TABLE `noticias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
