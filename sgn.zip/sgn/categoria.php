<?php
include('includes/header.php');
?>

  <div class="container">
  <div class="row">
  <?php
      $post_tags = $_GET['post'];
      $query = "SELECT * FROM noticias WHERE categoria='{$post_tags}' ORDER BY data_pub DESC";
      $run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
      if (mysqli_num_rows($run_query) > 0) {
      while ($row = mysqli_fetch_assoc($run_query)) {
        $post_title = $row['titulo'];
        $post_id = $row['id'];
        $post_author = $row['publicado_por'];
        $data_pub = $row['data_pub'];
        $post_imagem = $row['imagem'];
        $post_content = $row['texto'];

          ?>
                  
                
                  <div class="col-lg-8">
                    <hr>
                    <strong><h4><?php echo $post_title;?></h4></strong> 
                    <br>
                    <img class="img-responsive" style="height: 300px; width: 70%;" src="admin/views/<?php echo $post_imagem; ?>" alt="900 * 300">
                    <br>
                      <a href="categoria.php?post=<?= $post_tags; ?>"><span class="badge bg-dark"><?php echo $post_tags; ?> </span></a> <br>
                      
                      <p><?php echo substr($post_content, 0, 300); ?></p><a href="ver-mais.php?post=<?= $post_id; ?>"><button type="button" class="btn btn-primary">Ver mais<span class="glyphicon glyphicon-chevron-right"></span></button></a>
                      <hr>
                  </div>
                <?php }}?>
                </div>
  </div>
                  


<?php
include('includes/footer.php');
?>


