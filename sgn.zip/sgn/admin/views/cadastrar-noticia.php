<?php 
require_once("../controllers/logica-usuario.php");
require_once("../models/banco-categoria.php");
require_once("../class/Noticia.php");
require_once("../models/banco-categoria.php");
	verificaUsuario(); //verifica se o usuario esta logado
require_once("../partials/_header.php");

	$categorias = listaCategorias($conexao);
	//Instanciação de Objeto
	$noticia = new Noticia();

	//Atribuição inicial
	$noticia->id = "";
	$noticia->titulo = "";
	$noticia->texto = "";
	$noticia->imagem = "";
	$noticia->categoria = "";

?>
	<div class="breadcomb-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="breadcomb-list">
						<div class="row">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="breadcomb-wp">
									<div class="breadcomb-icon">
										<i class="notika-icon notika-windows"></i>
									</div>
									<div class="breadcomb-ctn">
										<h2>Publique uma Notícia</h2>
										<p>Fique atento as informações.</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Breadcomb area End-->

	<form enctype="multipart/form-data" class="needs-validation" method="POST" action="../controllers/adiciona-noticia.php">
		<?php require_once('../partials/_form_noticia.php'); ?>
		<button class="btn btn-primary notika-btn-primary btn-lg" type="submit">Publicar notícia</button>
	</div>
</form>


<?php require_once("../partials/_footer.php") ?>
