<?php 
require_once("../controllers/logica-usuario.php");
require_once("../models/banco.php");
require_once("../models/banco-noticia.php");
	verificaUsuario(); //verifica se o usuário está logado
	require_once("../partials/_header.php");
	require_once("../class/Noticia.php"); 

	$noticias = listaNoticias($conexao);
	?>
	<div class="breadcomb-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="breadcomb-list">
						<div class="row">
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
								<div class="breadcomb-wp">
									<div class="breadcomb-icon">
										<i class="notika-icon notika-windows"></i>
									</div>
									<div class="breadcomb-ctn">
										<h2>Todas as notícias publicadas</h2>
									</div>
								</div>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-3">
								<div class="breadcomb-report">
									<a href="cadastrar-noticia.php" data-toggle="tooltip" data-placement="left" title="Cadastrar novo Hóspede" class="btn"><i class="notika-icon notika-plus-symbol"></i></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Breadcomb area End-->

	<div class="data-table-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="data-table-list">
						<div class="table-responsive">
							<table id="data-table-basic" class="table table-striped">
								<thead>
									<tr>
										<th scope="col" class="text-center">Título</th>
										<th scope="col" class="text-center">Categoria</th>
										<th scope="col" class="text-center">Publicada Por</th>
										<th scope="col" class="text-center">Data da publicação</th>
										<th scope="col" class="text-center ">Mais Ações</th>
									</tr>
								</thead>
								<tbody>
									<?php 
									foreach ($noticias as $noticia) : ?>
										<tr>
											<td class="text-center"><?= $noticia->titulo ?></td>
											<td class="text-center"><?= $noticia->categoria ?></td>
											<td class="text-center"><?= $noticia->publicado_por ?></td>
											<td class="text-center"><?= $noticia->data_pub?></td>
											<td class="mais-acoes text-center" >
												<div class="btn-group notika-group-btn material-design-btn">
													<form class="mais-opcoes" method="POST" action="ficha-noticia.php">
											            <input type="hidden" name="id" value="<?=$noticia->id?>">
											            <button class="btn btn-success btn-sm notika-gp-success">F.N.R.H</button>
											        </form>
													<form class="mais-opcoes" action="ver-mais.php" >
														<input type="hidden" name="id" value="<?= $noticia->id ?>">
														<button class="btn btn-primary btn-sm notika-gp-primary">Ver Mais</button>
													</form>

													<form action="editar-noticia.php" class="mais-opcoes" method="post">
														<input type="hidden" name="id" value="<?=$noticia->id ?>">
														<button class="btn btn-default btn-sm">Editar</button>
													</form>
													<form class="mais-opcoes" action="../controllers/remover.php" method="post">
														<input type="hidden" name="id" value="<?=$noticia->id ?>" >
														<input type="hidden" name="recurso" value="noticias">
														<button class=" <?= $_SESSION['nivel_usuario'] == 'admin' ? '' : 'acesso-restrito';  ?> btn btn-sm btn-danger notika-gp-danger">Excluir</button>
													</form>
													
												</div>

											</td>
										</tr>		
									<?php endforeach ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<br>
	<a class="btn btn-primary notika-btn-primary btn-lg" href="cadastrar-noticia.php">Publicar Noticia</a>
	<?php require_once("../partials/_footer.php"); ?>