<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="form-element-list mg-t-30">
        <div class="cmp-tb-hd">
            <h2>Informações da Notícia</h2>
        </div>
        <div class="row">
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                <div class="form-group ic-cmp-int float-lb floating-lb">
                    <div class="form-ic-cmp">
                        <i class="notika-icon notika-paperclip"></i>
                    </div>
                    <div class="nk-int-st">
                        <input type="text" class="form-control" placeholder="Título da Notícia" name="titulo" value="<?=$noticia->titulo?>" >
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                <div class="form-group ic-cmp-int float-lb floating-lb">
                    <div class="form-ic-cmp">
                        <i class="notika-icon notika-paperclip"></i>
                    </div>
                    <div class="nk-int-st">
                        <select class="form-control"  name="categoria_id" id="categoria_id" >
                            <option value="">Categoria...</option>
                            <?php foreach ($categorias as $categoria) : 
                                $essaEhACategoria = $noticia->categoria->nome == $categoria->nome;
                                $selecao = $essaEhACategoria ? "selected='selected'" : "";
                                ?>
                                <option value="<?=$categoria->nome?>" <?=$selecao?> ><?=$categoria->nome?></option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                <div class="form-group ic-cmp-int float-lb floating-lb">
                    <div class="form-ic-cmp">
                        <i class="notika-icon notika-dollar"></i>
                    </div>
                    <div class="nk-int-st">
                        
                        <input type="file" class="form-control" name="arquivo" >
                        <input type="hidden" name="cadastrado_por" value="<?= $_SESSION['nome_usuario']?>">
                    </div>
                </div>
            </div>
        </div>
<br>

<div class="cmp-tb-hd">
    <h2>Texto</h2>
    <p>Utilize este campo para adicionar o texto da notícia</p>
</div>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="form-group ic-cmp-int float-lb form-elet-mg">
            <div class="nk-int-st infos-extras">
                <textarea class="form-control" id="informacoesAdicionais" name="texto" rows="9" value="<?=$noticia->texto?>" ></textarea>
            </div>
        </div>
    </div>
</div>
</div><br>
