	<!-- Inicio do rodape -->
	<br>
</div>  <!-- Fim da div container -->

</div>	<!-- Fim da div principal -->
<footer class="py-5 bg-dark rodape-sistema">
	<div class="container">
		<p class="m-0 text-center text-white">Criado por &copy; Por Grupo4</a>;</p>
	</div>
	<!-- /.container -->
</footer>

<!-- Javascript includes -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="../assets/js/bootstrap.js"></script>


</body>
</html>