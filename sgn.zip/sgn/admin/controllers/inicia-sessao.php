<?php session_start(); 
