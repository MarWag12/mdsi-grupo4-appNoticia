<?php

require_once("../controllers/logica-usuario.php");
require_once("../models/conecta.php");
require_once("../class/Noticia.php");
require_once("../models/banco-noticia.php");

    verificaUsuario(); //verifica se o usuário está logado
	require_once("../partials/_header.php"); 

    $noticia = new Noticia(); //instanciação de um objeto usuário

    $noticia->categoria = $_POST["categoria_id"]; 	
	$noticia->texto = $_POST["texto"];
	$noticia->cadastradoPor = $_POST["cadastrado_por"];
	$noticia->titulo = $_POST["titulo"];


    
		if (isset($_FILES['arquivo'])) {
			$arquivo = $_FILES['arquivo'];
			if ($arquivo['error']) 
			 die('Falha ao enviar a imagem');
	
			 $pasta = "../imagens/imagens_noticias/";
			 $nomeDoArquivo =  $arquivo['name'];
			 $nomeNomeDoArquivo =  uniqid();
			 $extensao = strtolower(pathinfo($nomeDoArquivo, PATHINFO_EXTENSION));
	
			 if($extensao != 'jpg' && $extensao != 'png')
				die("Tipo de arquivo não aceito");
			$path = $pasta . $nomeNomeDoArquivo . "." . $extensao;
			$deu_certo = move_uploaded_file($arquivo["tmp_name"], $path);
		}
		$noticia->imagem = $path;

if (cadastraNoticia($conexao, $noticia)) { 
    $_SESSION["success"] = "A noticia foi publicada com sucesso!";
    echo "<script>location.href='../views/listar-noticias.php';</script>";
    die();
}

else {
    $msg = mysqli_error($conexao);
    echo $msg;
    $_SESSION["danger"] = "O usuário não foi cadastrado. Tente novamente!";
    //echo "<script>location.href='../views/listar-usuarios.php';</script>";
    die();
}
?>