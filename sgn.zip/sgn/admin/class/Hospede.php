<?php 

	class Hospede {
		public $id;
		public $nome;
		public $cpf;
		public $dataNascimento;
		public $sexo;
		public $telefone;
		public $celular;
		public $email;
		public $estadoCivil;
		public $cep;
		public $rua;
		public $bairro;
		public $cidade;
		public $estado;
		public $dataCheckin;
		public $dataCheckout;
		public $qtdDiarias;
		public $qtdAcompanhantes;
		public $precoDiaria;
		public $valorPago; //sinal
		public $precoTotal;
		public $totalPagar;
		public $infoExtras;
		public $categoria;
		public $cadastradoPor;
	}