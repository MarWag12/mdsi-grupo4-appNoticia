<?php 

	class Empresa {
		public $id;
		public $nif;
		public $nome;
		public $razaoSocial;
		public $endereco;
		public $telefone;
		public $email;
		public $site;
	}