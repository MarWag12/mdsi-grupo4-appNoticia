<?php 

	class Usuario {
		public $id;
		public $nome;
		public $email;
		public $telefone;
		public $foto;
		public $senha;
		public $permissao;
	}