<?php 

	class Noticia {
		public $id;
		public $texto;
		public $titulo;
		public $data_pub;
		public $imagem;
		public $publicado_por;
		public $categoria;
	}