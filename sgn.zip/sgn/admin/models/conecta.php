<?php 
$servername = "localhost";
$database = "sgn";
$username = "root";
$password = "";

$conexao = mysqli_connect($servername, $username, $password, $database);