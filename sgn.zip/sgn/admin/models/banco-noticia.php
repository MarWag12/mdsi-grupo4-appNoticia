<?php 
	require_once("conecta.php");
	require_once("../class/Noticia.php");


	function cadastraNoticia($conexao, Noticia $noticia){

		$query = "INSERT INTO noticias (titulo, texto, categoria, imagem, publicado_por, data_pub) VALUES ('{$noticia->titulo}', '{$noticia->texto}', '{$noticia->categoria}', '{$noticia->path}', '{$noticia->cadastradoPor}',NOW())";
		$resultadoConexao = mysqli_query($conexao, $query);
		return $resultadoConexao;
	}

function listaNoticias ($conexao) {
	$noticias = array();
	$query = "SELECT * FROM noticias";
	$resultado = mysqli_query($conexao, $query);
	
	while ($noticia_array = mysqli_fetch_assoc($resultado)) {

		//Instanciação de Objeto
		$noticia = new Noticia();

		//Atribuição dos atributos
		$noticia->id = $noticia_array['id'];
		$noticia->titulo = $noticia_array['titulo'];
		$noticia->texto = $noticia_array['texto'];
		$noticia->categoria = $noticia_array['categoria'];
		$noticia->publicado_por = $noticia_array['publicado_por'];
		$noticia->data_pub = $noticia_array['data_pub'];

		array_push($noticias, $noticia);
	}
	return $noticias;

}


function buscaNoticia ($conexao, $id) {
	$query = "SELECT * FROM noticias WHERE id={$id}";
	$resultado = mysqli_query($conexao, $query);
	$noticia_buscada = mysqli_fetch_assoc($resultado); //é um array
	
	//Instanciação do objeto
	$noticia = new Noticia();

	$noticia->id = $noticia_buscada['id'];
	$noticia->titulo = $noticia_buscada['titulo'];
	$noticia->imagem = $noticia_buscada['imagem'];
	$noticia->texto = $noticia_buscada['texto'];
	$noticia->categoria = $noticia_buscada['categoria'];
	$noticia->publicado_por = $noticia_buscada['publicado_por'];
	$noticia->data_pub = $noticia_buscada['data_pub'];

	return $noticia;
}

function alteraNoticia ($conexao, Noticia $noticia) {
	//Evita ataque de sql injection -> aceita a aspa simples Ex. Joana D'arc
	$noticia->titulo = mysqli_real_escape_string($conexao, $noticia->titulo);
	$noticia->texto = mysqli_real_escape_string($conexao, $noticia->texto);
	$noticia->categoria = mysqli_real_escape_string($conexao, $noticia->categoria);
	$noticia->publicado_por = mysqli_real_escape_string($conexao, $noticia->publicado_por);
	$noticia->imagem = mysqli_real_escape_string($conexao, $noticia->imagem);


	if (strlen($noticia->senha) == 32) {
		$query = "UPDATE noticias SET titulo = '{$noticia->titulo}', categoria = '{$noticia->categoria}', imagem = '{$noticia->imagem}', texto = '{$noticia->texto}' WHERE id={$noticia->id}";
	}

	else {
		$noticia->senha = md5($noticia->senha);
		$query = "UPDATE noticias SET titulo = '{$noticia->titulo}', categoria = '{$noticia->categoria}', imagem = '{$noticia->imagem}', texto = '{$usuario->texto}' WHERE id={$noticia->id}";
	}
	
	$resultado = mysqli_query($conexao, $query);
	return $resultado;
}










