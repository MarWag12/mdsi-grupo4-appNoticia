<?php 
	require_once("conecta.php");
	require_once("../class/Empresa.php");


function buscaEmpresa ($conexao, $id) {
	$query = "SELECT * FROM empresa WHERE id={$id}";
	$resultado = mysqli_query($conexao, $query);
	$empresa_buscada = mysqli_fetch_assoc($resultado); //é um array
	
	//Instanciação do objeto
	$empresa = new Empresa();

	$empresa->id = $empresa_buscada['id'];
	$empresa->nif = $empresa_buscada['nif'];
	$empresa->nome = $empresa_buscada['nome'];
	$empresa->razaoSocial = $empresa_buscada['razao_social'];
	$empresa->endereco = $empresa_buscada['endereco'];
	$empresa->telefone = $empresa_buscada['telefone'];
	$empresa->email = $empresa_buscada['email'];
	$empresa->site = $empresa_buscada['site'];

	return $empresa;
}

function alteraEmpresa ($conexao, Empresa $empresa) {

	$empresa->nif = mysqli_real_escape_string($conexao, $empresa->nif);
	$empresa->nome = mysqli_real_escape_string($conexao, $empresa->nome);
	$empresa->razaoSocial = mysqli_real_escape_string($conexao, $empresa->razaoSocial);
	$empresa->endereco = mysqli_real_escape_string($conexao, $empresa->endereco);
	$empresa->telefone = mysqli_real_escape_string($conexao, $empresa->telefone);
	$empresa->email = mysqli_real_escape_string($conexao, $empresa->email);
	$empresa->site = mysqli_real_escape_string($conexao, $empresa->site);

	$query = "UPDATE empresa SET nif = '{$empresa->nif}', nome = '{$empresa->nome}', razao_social = '{$empresa->razaoSocial}', endereco = '{$empresa->endereco}', telefone = '{$empresa->telefone}', email = '{$empresa->email}', site = '{$empresa->site}' WHERE id = '{$empresa->id}' ";

	return mysqli_query($conexao, $query);
}