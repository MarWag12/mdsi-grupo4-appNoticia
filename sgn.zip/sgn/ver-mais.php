<?php
include('includes/header.php');


$post = $_GET['post'];
$query = "SELECT * FROM noticias WHERE id=$post";
$run_query = mysqli_query($conn, $query);
$row = mysqli_fetch_array($run_query);

        $post_title = $row['titulo'];
        $post_id = $row['id'];
        $post_author = $row['publicado_por'];
        $data_pub = $row['data_pub'];
        $post_imagem = $row['imagem'];
        $post_content = $row['texto'];
        $post_tags = $row['categoria'];

	?>
 <main>
<!-- ======= About Section ======= -->
  <section class="about section-bg">
      <div class="container" data-aos="fade-up">
      <h1 class="logo"><?php echo $post_title; ?></h1>
            <img src="admin/views/<?php echo $post_imagem; ?>" style="height: 420px; width: 500px;" class="img-fluid" alt="">
            <p class="fst-italic">
            <?php echo $post_content; ?>
            </p>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->
</main>
<?php
include('includes/footer.php');
?>