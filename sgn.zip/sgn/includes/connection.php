<?php
$conn = mysqli_connect("localhost","root","","sgn" ) or die ("error" . mysqli_error($conn));
?>